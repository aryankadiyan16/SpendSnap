package com.example.finance_app_master

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
