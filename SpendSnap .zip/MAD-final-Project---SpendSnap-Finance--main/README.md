<h1>Finance App</h1>

<h3>
SpendSnap is a personal finance management app developed using 
Flutter, aimed at helping users efficiently track their income, 
expenses, and budgets. With an intuitive user interface, SpendSnap 
makes it easy for users to manually input and categorize their
financial transactions, offering clear insights into their spending 
habits.
</h3>
<!-- <p>
Here below are some snapshots of the project 
</p>
<hr>
<div style = ""> 
<img src="[C:\Users\Tanya\OneDrive\Desktop](https://lh3.googleusercontent.com/pw/AP1GczPeOA5yyAOl96uyS6a3_TXelvqqjidrl7sNEos-hzBNL4wYT505ZOpobzBq-T6hFZkDLgW4HOAo2xx9k2b68kbZ4pdpgwIMt-tMTtBv8rePcdXaK3rQ=w2400)" alt="" width="20%"/>
<img src="" alt="" width="32%"/>
<img src="" alt="" width="32%"/>
</div>
 -->
